import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main(){
  const pass = await bcrypt.hash("prime123", 10);
  const owner = await prisma.user.upsert({
    where: { email: "owner@primepanel.local" },
    update: {},
    create: { name: "Owner", email: "owner@primepanel.local", passwordHash: pass, role: "OWNER" }
  });
  const installer = await prisma.user.upsert({
    where: { email: "monter@primepanel.local" },
    update: {},
    create: { name: "Monter", email: "monter@primepanel.local", passwordHash: pass, role: "INSTALLER" }
  });
  const architect = await prisma.user.upsert({
    where: { email: "architekt@primepanel.local" },
    update: {},
    create: { name: "Architekt", email: "architekt@primepanel.local", passwordHash: pass, role: "ARCHITECT" }
  });
  console.log({ owner, installer, architect });
}

main().catch(e=>{ console.error(e); process.exit(1); }).finally(()=> prisma.$disconnect());
