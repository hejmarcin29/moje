import { promises as fs } from 'fs'
import path from 'path'

export async function saveLocal(buffer: Buffer, name: string, mime: string){
  const dir = path.join(process.cwd(), 'uploads')
  await fs.mkdir(dir, { recursive: true })
  const full = path.join(dir, name)
  await fs.writeFile(full, buffer)
  return `/uploads/${encodeURIComponent(name)}`
}
