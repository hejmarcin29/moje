'use client'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'

export function Nav(){
  const { data } = useSession()
  const role = (data?.user as any)?.role
  return (
    <nav className="border-b">
      <div className="container flex items-center gap-4 h-14">
        <Link href="/dashboard" className="font-semibold">PrimePanel</Link>
        <div className="flex gap-3 text-sm">
          <Link href="/jobs">Zlecenia</Link>
          {role !== 'ARCHITECT' && <Link href="/jobs/new" className="text-brand">Nowe zlecenie</Link>}
        </div>
        <div className="ml-auto flex items-center gap-3 text-sm">
          <span className="text-gray-500 hidden sm:inline">{data?.user?.name} ({role})</span>
          <button className="btn" onClick={()=>signOut({ callbackUrl: '/login' })}>Wyloguj</button>
        </div>
      </div>
    </nav>
  )
}
