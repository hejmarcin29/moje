export const runtime = 'nodejs'

import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'
import { saveLocal } from '@/lib/upload'

export async function POST(req: Request){
  const form = await req.formData()
  const file = form.get('file') as File | null
  const jobId = String(form.get('jobId') || '')
  if(!file || !jobId) return NextResponse.json({ ok:false }, { status:400 })
  const buf = Buffer.from(await file.arrayBuffer())
  const name = `${Date.now()}-${file.name}`
  const url = await saveLocal(buf, name, file.type)
  await prisma.file.create({ data: { url, name: file.name, mime: file.type, sizeBytes: buf.length, jobId } })
  return NextResponse.json({ ok:true, url })
}
