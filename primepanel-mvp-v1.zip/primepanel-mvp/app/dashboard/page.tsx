import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { Nav } from '@/components/nav'

export default async function Dashboard(){
  const session = await getServerSession(authOptions)
  const role = (session?.user as any)?.role as 'OWNER'|'INSTALLER'|'ARCHITECT'

  const jobs = await prisma.job.findMany({
    orderBy: { createdAt: 'desc' },
    take: 8,
    include: { createdBy: true, assignedTo: true, measurement: true }
  })

  return (
    <div>
      <Nav/>
      <div className="container py-6">
        <h1 className="text-2xl font-semibold mb-4">Panel — ostatnie zlecenia</h1>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {jobs.map(j=> (
            <a key={j.id} href={`/jobs/${j.id}`} className="card p-4 hover:shadow-md transition">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">{j.title}</h3>
                <span className="text-xs px-2 py-0.5 rounded-full border">{j.status}</span>
              </div>
              <p className="text-sm text-gray-600 mt-1">{j.address}, {j.city} • {j.phone}</p>
              <p className="text-xs text-gray-500 mt-2">Utworzył: {j.createdBy.name} {j.assignedTo ? `• Monter: ${j.assignedTo.name}`:''}</p>
              {j.measurement && <p className="text-xs text-gray-500">Pomiar: {new Date(j.measurement.when).toLocaleDateString('pl-PL')}</p>}
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}
