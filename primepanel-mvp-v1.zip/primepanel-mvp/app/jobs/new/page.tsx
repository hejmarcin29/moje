import { getServerSession } from 'next-auth'
import { authOptions, roleAllows } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { redirect } from 'next/navigation'
import { Nav } from '@/components/nav'

export default async function NewJob(){
  const session = await getServerSession(authOptions)
  const role = (session?.user as any)?.role
  if(!roleAllows(role, ['OWNER', 'INSTALLER'])) redirect('/dashboard')

  const installers = await prisma.user.findMany({ where: { role: 'INSTALLER' } })

  return (
    <div>
      <Nav/>
      <div className="container py-6 max-w-2xl">
        <h1 className="text-2xl font-semibold mb-4">Nowe zlecenie</h1>
        <form action={createJob} className="space-y-4">
          <div>
            <label className="label">Tytuł</label>
            <input name="title" className="input" placeholder="Montaż SPC + pomiar" required />
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="label">Adres</label>
              <input name="address" className="input" required />
            </div>
            <div>
              <label className="label">Miasto</label>
              <input name="city" className="input" required />
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="label">Telefon klienta</label>
              <input name="phone" className="input" required />
            </div>
            <div className="flex items-center gap-2 mt-6">
              <input id="withInstall" name="withInstall" type="checkbox" defaultChecked className="h-4 w-4" />
              <label htmlFor="withInstall" className="text-sm">Z montażem</label>
            </div>
          </div>
          <div>
            <label className="label">Przypisz montera</label>
            <select name="assignedToId" className="input">
              <option value="">—</option>
              {installers.map(i=> <option key={i.id} value={i.id}>{i.name}</option>)}
            </select>
          </div>
          <button className="btn btn-primary">Utwórz</button>
        </form>
      </div>
    </div>
  )
}

async function createJob(formData: FormData){
  'use server'
  const session = await getServerSession(authOptions)
  if(!session?.user) return
  const title = String(formData.get('title'))
  const address = String(formData.get('address'))
  const city = String(formData.get('city'))
  const phone = String(formData.get('phone'))
  const assignedToId = String(formData.get('assignedToId')||'') || null
  const withInstall = !!formData.get('withInstall')

  const job = await prisma.job.create({ data: {
    title, address, city, phone, withInstall,
    createdById: (session.user as any).id,
    assignedToId
  }})

  if (process.env.N8N_WEBHOOK_URL){
    fetch(process.env.N8N_WEBHOOK_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ type:'job.created', job }) }).catch(()=>{})
  }

  redirect(`/jobs/${job.id}`)
}
