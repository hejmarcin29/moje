import { prisma } from '@/lib/prisma'
import { Nav } from '@/components/nav'

export default async function JobsPage(){
  const jobs = await prisma.job.findMany({ orderBy: { createdAt: 'desc' }, include: { assignedTo: true } })
  return (
    <div>
      <Nav/>
      <div className="container py-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-semibold">Wszystkie zlecenia</h1>
          <a href="/jobs/new" className="btn btn-primary">Nowe zlecenie</a>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-3">Tytuł</th>
                <th className="py-2 pr-3">Miasto</th>
                <th className="py-2 pr-3">Telefon</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3">Monter</th>
                <th className="py-2 pr-3">Data</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map(j => (
                <tr key={j.id} className="border-b hover:bg-gray-50">
                  <td className="py-2 pr-3"><a className="text-brand" href={`/jobs/${j.id}`}>{j.title}</a></td>
                  <td className="py-2 pr-3">{j.city}</td>
                  <td className="py-2 pr-3">{j.phone}</td>
                  <td className="py-2 pr-3">{j.status}</td>
                  <td className="py-2 pr-3">{j.assignedTo?.name ?? '-'}</td>
                  <td className="py-2 pr-3">{new Date(j.createdAt).toLocaleDateString('pl-PL')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
