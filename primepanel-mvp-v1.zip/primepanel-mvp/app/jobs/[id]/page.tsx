import { getServerSession } from 'next-auth'
import { authOptions, roleAllows } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { notFound } from 'next/navigation'
import { Nav } from '@/components/nav'
import { revalidatePath } from 'next/cache'

export default async function JobPage({ params }: { params: { id: string }}){
  const session = await getServerSession(authOptions)
  const role = (session?.user as any)?.role as 'OWNER'|'INSTALLER'|'ARCHITECT'
  const job = await prisma.job.findUnique({ where: { id: params.id }, include: { createdBy: true, assignedTo: true, measurement: { include: { files: true }}, files: true, comments: { include: { author: true }, orderBy: { createdAt: 'desc' }}} })
  if(!job) return notFound()

  const canEditMeasurement = roleAllows(role, ['OWNER','INSTALLER'])
  const isArchitect = role === 'ARCHITECT'

  async function updateStatus(formData: FormData){
    'use server'
    const session2 = await getServerSession(authOptions)
    const role2 = (session2?.user as any)?.role
    if(!roleAllows(role2, ['OWNER','INSTALLER'])) return
    const status = String(formData.get('status')) as any
    const jobUpd = await prisma.job.update({ where: { id: job.id }, data: { status } })
    if (process.env.N8N_WEBHOOK_URL){
      fetch(process.env.N8N_WEBHOOK_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ type:'job.status', job: jobUpd }) }).catch(()=>{})
    }
    revalidatePath(`/jobs/${job.id}`)
  }

  async function addComment(formData: FormData){
    'use server'
    const session2 = await getServerSession(authOptions)
    if(!session2?.user) return
    const text = String(formData.get('text') || '')
    if(!text.trim()) return
    await prisma.comment.create({ data: { jobId: job.id, authorId: (session2.user as any).id, text } })
    revalidatePath(`/jobs/${job.id}`)
  }

  async function saveQuote(formData: FormData){
    'use server'
    const session2 = await getServerSession(authOptions)
    const role2 = (session2?.user as any)?.role
    if(!roleAllows(role2, ['OWNER','INSTALLER'])) return
    const quotePLN = Number(formData.get('quotePLN') ?? '0')
    await prisma.job.update({ where: { id: job.id }, data: { quotePLN } })
    revalidatePath(`/jobs/${job.id}`)
  }

  async function uploadJobFile(formData: FormData){
    'use server'
    const session2 = await getServerSession(authOptions)
    if(!session2?.user) return
    const file = formData.get('file') as File | null
    if(!file) return
    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)
    const name = `${Date.now()}-${file.name}`
    const { saveLocal } = await import('@/lib/upload')
    const url = await saveLocal(buffer, name, file.type)
    await prisma.file.create({ data: { url, name: file.name, mime: file.type, sizeBytes: buffer.length, jobId: job.id } })
    revalidatePath(`/jobs/${job.id}`)
  }

  async function saveMeasurement(formData: FormData){
    'use server'
    const session2 = await getServerSession(authOptions)
    const role2 = (session2?.user as any)?.role
    if(!roleAllows(role2, ['OWNER','INSTALLER'])) return
    const when = new Date(String(formData.get('when')))
    const areaM2 = Number(formData.get('areaM2'))
    const subfloor = String(formData.get('subfloor'))
    const notes = String(formData.get('notes') || '')
    const roomsJson = JSON.parse(String(formData.get('roomsJson') || '[]'))
    if(job.measurement){
      await prisma.measurement.update({ where: { id: job.measurement.id }, data: { when, areaM2, subfloor, notes, roomsJson } })
    } else {
      await prisma.measurement.create({ data: { jobId: job.id, when, areaM2, subfloor, notes, roomsJson } })
    }
    await prisma.job.update({ where: { id: job.id }, data: { status: 'MEASURED' } })
    if (process.env.N8N_WEBHOOK_URL){
      fetch(process.env.N8N_WEBHOOK_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ type:'job.measured', jobId: job.id }) }).catch(()=>{})
    }
    revalidatePath(`/jobs/${job.id}`)
  }

  return (
    <div>
      <Nav/>
      <div className="container py-6 grid lg:grid-cols-3 gap-6">
        <section className="card p-4 lg:col-span-2">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-xl font-semibold">{job.title}</h1>
              <p className="text-sm text-gray-600">{job.address}, {job.city} • tel. {job.phone}</p>
              <p className="text-xs text-gray-500 mt-1">Utworzył: {job.createdBy.name} {job.assignedTo ? `• Monter: ${job.assignedTo.name}`:''}</p>
            </div>
            <form action={updateStatus} className="flex items-center gap-2">
              {!isArchitect && (
                <select name="status" defaultValue={job.status} className="input text-sm">
                  {['NEW','MEASUREMENT_SCHEDULED','MEASURED','QUOTED','APPROVED','IN_PROGRESS','DONE','CANCELLED'].map(s=> <option key={s} value={s}>{s}</option>)}
                </select>
              )}
              {!isArchitect && <button className="btn">Zapisz</button>}
            </form>
          </div>

          <div className="mt-6">
            <h2 className="font-medium mb-2">Pomiar</h2>
            {job.measurement ? (
              <div className="text-sm text-gray-700">
                <p><strong>Termin:</strong> {new Date(job.measurement.when).toLocaleString('pl-PL')}</p>
                <p><strong>Powierzchnia:</strong> {job.measurement.areaM2} m²</p>
                <p><strong>Podłoże:</strong> {job.measurement.subfloor}</p>
                {job.measurement.notes && <p><strong>Notatki:</strong> {job.measurement.notes}</p>}
                {Array.isArray(job.measurement.roomsJson) && (job.measurement.roomsJson as any[]).length > 0 && (
                  <div className="mt-2">
                    <strong>Pomieszczenia:</strong>
                    <ul className="list-disc ml-5">
                      {(job.measurement.roomsJson as any[]).map((r:any, idx:number)=>(
                        <li key={idx}>{r.name}: {r.m2} m²</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-sm text-gray-500">Brak danych z pomiaru.</div>
            )}
          </div>

          {canEditMeasurement && (
            <div className="mt-6">
              <h3 className="font-medium mb-2">{job.measurement? 'Edytuj pomiar':'Dodaj pomiar'}</h3>
              <form action={saveMeasurement} className="space-y-3">
                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="label">Termin pomiaru</label>
                    <input type="datetime-local" name="when" className="input" required />
                  </div>
                  <div>
                    <label className="label">Powierzchnia (m²)</label>
                    <input type="number" step="0.01" name="areaM2" className="input" placeholder="np. 58.4" required />
                  </div>
                </div>
                <div>
                  <label className="label">Pomieszczenia (JSON)</label>
                  <textarea name="roomsJson" className="input" rows={3} placeholder='[{"name":"salon","m2":22.5}]'></textarea>
                </div>
                <div>
                  <label className="label">Podłoże</label>
                  <input name="subfloor" className="input" placeholder="wylewka, płytki, różnice do 5 mm..." />
                </div>
                <div>
                  <label className="label">Notatki</label>
                  <textarea name="notes" className="input" rows={3} placeholder="np. potrzeba podlania w kuchni, listwy PVC 50 mb..."></textarea>
                </div>
                <button className="btn">Zapisz pomiar</button>
              </form>
            </div>
          )}

          <div className="mt-6">
            <h2 className="font-medium mb-2">Pliki do zlecenia</h2>
            <ul className="space-y-2 text-sm">
              {job.files.map(f=> (
                <li key={f.id} className="flex items-center justify-between border rounded-lg px-3 py-2">
                  <a href={f.url} target="_blank" rel="noreferrer" className="text-brand underline">{f.name}</a>
                  <span className="text-xs text-gray-500">{(f.sizeBytes/1024).toFixed(1)} KB</span>
                </li>
              ))}
              {!isArchitect && (
                <li>
                  <form action={uploadJobFile} className="mt-3 flex gap-2 items-center" encType="multipart/form-data">
                    <input className="input" type="file" name="file" />
                    <button className="btn">Wyślij plik</button>
                  </form>
                </li>
              )}
            </ul>
          </div>
        </section>

        <aside className="card p-4">
          <h3 className="font-medium mb-3">Komentarze</h3>
          <div className="space-y-3">
            {job.comments.map(c=> (
              <div key={c.id} className="border p-3 rounded-lg">
                <div className="text-xs text-gray-500">
                  {new Date(c.createdAt).toLocaleString('pl-PL')} • {c.author.name}
                </div>
                <div className="text-sm">{c.text}</div>
              </div>
            ))}
          </div>
          <form action={addComment} className="mt-3 flex gap-2">
            <input name="text" className="input" placeholder="Dodaj komentarz / notatkę" />
            <button className="btn">Wyślij</button>
          </form>

          <div className="mt-6">
            <h3 className="font-medium mb-2">Wycena (PLN brutto)</h3>
            <form action={saveQuote} className="flex gap-2 items-center">
              <input name="quotePLN" type="number" defaultValue={job.quotePLN ?? ''} className="input" placeholder="np. 12500" />
              {!isArchitect && <button className="btn">Zapisz</button>}
            </form>
          </div>
        </aside>
      </div>
    </div>
  )
}
