'use client'
import { signIn } from 'next-auth/react'
import { FormEvent, useState } from 'react'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')

  async function onSubmit(e: FormEvent){
    e.preventDefault()
    setErr('')
    const res = await signIn('credentials', { email, password, redirect: false })
    if(res?.ok) window.location.href = '/dashboard'
    else setErr('Błędne dane logowania')
  }

  return (
    <div className="min-h-screen grid place-items-center">
      <form onSubmit={onSubmit} className="card w-full max-w-sm p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Logowanie</h1>
        <div>
          <label className="label">Email</label>
          <input className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="architekt@primepanel.local" />
        </div>
        <div>
          <label className="label">Hasło</label>
          <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="prime123" />
        </div>
        {err && <p className="text-red-600 text-sm">{err}</p>}
        <button className="btn btn-primary w-full" type="submit">Zaloguj</button>
        <p className="text-xs text-gray-500">Testowe konta: owner@primepanel.local, monter@primepanel.local, architekt@primepanel.local (hasło: prime123)</p>
      </form>
    </div>
  )
}
