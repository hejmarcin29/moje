import Link from 'next/link'

export default function Home(){
  return (
    <main className="min-h-screen grid place-items-center">
      <div className="card p-8 text-center space-y-4">
        <h1 className="text-3xl font-semibold">PrimePanel — logowanie</h1>
        <p className="text-gray-600">Panel dla montażystów i architektów (wgląd w pomiary).</p>
        <Link className="btn btn-primary" href="/login">Przejdź do logowania</Link>
      </div>
    </main>
  )
}
